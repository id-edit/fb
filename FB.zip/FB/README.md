# Facebook ฟลัดเม้น
by [ARYouMe!](https://facebook.com/iboy.sloth)

### How to
```
apt install python3
apt install git
git clone https://github.com/aryoume/Project1
cd Project1
python3 main.py
```

### งั่มๆ
